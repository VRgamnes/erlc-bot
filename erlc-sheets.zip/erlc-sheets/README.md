# ERLC Staff Log → Google Sheets (no Discord needed)

Every ~10 minutes, this pulls your ERLC server's command log and drops new
entries into a Google Sheet — one tab with *everything* ("Commands"), one
tab with just `:log` entries ("Warns"). Completely free.

## How it fits together

1. GitHub Action runs on a schedule, calls the ERLC API for command logs.
2. It sends any new entries to a small Google Apps Script "web app" that's
   glued directly to your Sheet.
3. The Apps Script writes each entry into the **Commands** tab, and if the
   command starts with `:log`, also into the **Warns** tab.

No Google Cloud account, no service account keys, no Discord — just Apps
Script, which is built into every Google Sheet for free.

## Setup (about 15 minutes, one time)

### 1. Create the Google Sheet
- Make a new Google Sheet (any name, e.g. "NYS Staff Log").
- You don't need to create the tabs yourself — the script creates
  "Commands" and "Warns" automatically on first run.

### 2. Add the Apps Script
- In the Sheet: **Extensions → Apps Script**.
- Delete anything in the editor and paste in the contents of
  `apps-script/Code.gs` from this project.
- Change the line near the top:
  ```
  const SHARED_SECRET = "CHANGE-THIS-TO-YOUR-OWN-SECRET";
  ```
  to any random string only you know (this stops randoms from spamming your
  sheet if they ever guessed the URL). Keep it somewhere safe — you'll need
  it again in step 4.

### 3. Deploy it as a Web App
- Top right of the Apps Script editor: **Deploy → New deployment**.
- Click the gear icon next to "Select type" → choose **Web app**.
- Settings:
  - Execute as: **Me**
  - Who has access: **Anyone** (this only controls who can *reach* the
    URL — your secret string is what actually gates access)
- Click **Deploy**, authorize it with your Google account when prompted.
- Copy the **Web app URL** it gives you (ends in `/exec`). You'll need it
  in step 4.

### 4. Create the GitHub repo
- Create a new GitHub repo and upload all the files in this project,
  keeping the folder structure (`.github/`, `scripts/`, `data/`).
- Repo → **Settings → Secrets and variables → Actions → New repository
  secret**, and add three secrets:
  - `ERLC_SERVER_KEY` — your ERLC server key (Settings → ER:LC API section
    in your private server)
  - `SHEETS_WEBHOOK_URL` — the Web app URL from step 3
  - `WEBHOOK_SECRET` — the secret string you set in step 2

### 5. Turn on Actions
- Repo → **Actions** tab → enable workflows if prompted.
- You can trigger the first run manually: Actions tab → "Sync ERLC Command
  Logs to Google Sheets" → **Run workflow**. After ~30 seconds, check your
  Sheet — the Commands tab (and Warns tab, if any `:log` commands ran
  recently) should start filling in.
- After that it runs automatically every 10 minutes.

## Troubleshooting

- **Nothing shows up**: check Actions tab → click the run → read the logs.
  Most common causes: a secret name typo, or the Apps Script deployment
  access setting isn't "Anyone."
- **401 unauthorized in the logs**: the `WEBHOOK_SECRET` GitHub secret
  doesn't match `SHARED_SECRET` in the Apps Script — they must be identical.
- **Field names look off** (e.g. "Player" column is blank): the ERLC API's
  exact response field names weren't confirmed from public docs. Open the
  Action run logs to see the raw response, then adjust `fieldPlayer` /
  `fieldCommand` / `fieldTimestamp` near the top of `scripts/fetch-logs.js`
  to match.
- **Re-deploying after edits**: if you change `Code.gs` later, use
  **Deploy → Manage deployments → Edit (pencil icon) → New version** —
  just saving the file isn't enough to update the live web app.

## Notes

- This only *reads* command logs — nothing here can run commands on your
  server.
- Keep your ERLC server key and webhook secret private even though the
  repo can be public; that's what the GitHub secrets are for.
- `data/seen.json` just tracks which log entries have already been sent,
  so restarts don't duplicate rows in your sheet. You never need to touch it.
