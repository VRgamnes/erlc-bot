/**
 * Paste this into the Apps Script editor attached to your Google Sheet
 * (Extensions > Apps Script), replace the SHARED_SECRET value below,
 * then deploy it as a Web App (see README.md for exact steps).
 *
 * Expects the sheet to have two tabs named exactly:
 *   Commands
 *   Warns
 * (the script will create them with headers if they don't exist yet)
 */

const SHARED_SECRET = "CHANGE-THIS-TO-YOUR-OWN-SECRET"; // must match GH secret WEBHOOK_SECRET

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);

    if (body.secret !== SHARED_SECRET) {
      return jsonResponse({ ok: false, error: "unauthorized" }, 401);
    }

    const entries = body.entries || [];
    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const commandsSheet = getOrCreateSheet(ss, "Commands");
    const warnsSheet = getOrCreateSheet(ss, "Warns");

    let warnCount = 0;

    entries.forEach((entry) => {
      const row = [entry.time || "", entry.player || "", entry.command || ""];
      commandsSheet.appendRow(row);

      if (/^:log\b/i.test(entry.command || "")) {
        warnsSheet.appendRow(row);
        warnCount++;
      }
    });

    return jsonResponse({ ok: true, added: entries.length, warns: warnCount });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err) }, 500);
  }
}

function getOrCreateSheet(ss, name) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow(["Time", "Staff Member", "Command"]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function jsonResponse(obj, code) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// Optional: lets you hit the deployed URL in a browser to sanity-check it's alive
function doGet(e) {
  return jsonResponse({ ok: true, message: "ERLC log receiver is running." });
}
